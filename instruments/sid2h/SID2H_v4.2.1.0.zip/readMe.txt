April 16, 2010
Peak detector cards were built by U. Hertfordshire and installed in SID2H.  

V4.2.1.0 updated software was also provided on a CD, and I put it into a zip file.
  ..Dave R..