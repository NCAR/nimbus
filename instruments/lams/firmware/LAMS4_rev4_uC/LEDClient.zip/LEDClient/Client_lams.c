/*----------------------------------------------------------------------------
 *      RL-ARM - TCPnet
 *----------------------------------------------------------------------------
 *      Name:    CLIENT.C
 *      Purpose: LED Control Client demo example
 *----------------------------------------------------------------------------
 *      This code is part of the RealView Run-Time Library.
 *      Copyright (c) 2004-2009 KEIL - An ARM Company. All rights reserved.
 *---------------------------------------------------------------------------*/

#include <RTL.h>
#include <stdio.h>
#include <string.h>
#include <LPC23xx.H>                    /* LPC23xx definitions              */

#define MCLK 48000000                   /* Master Clock 48 MHz              */
#define TCLK      100                   /* Timer Clock rate 100/s PCLK=12MHz */
//#define TCLK       10                         /* Timer Clock rate 10/s       */
#define TCNT (MCLK/TCLK/4)              /* Timer Counts  = 120000          */

//-------- <<< Use Configuration Wizard in Context Menu >>> -----------------

//   <h>Remote IP Address
//   ====================
//
//     <o>IP1: Address byte 1 <0-255>
//     <i> Default: 192
#define IP1            192 
#define IP2            168
#define IP3            184
#define IP4            255

//   <o>Remote Port <1-65535>
//   <i> Do not set number of port too small,
//   <i> maybe it is already used.
//   <i> Default: 1001
#define PORT_NUM       1001

//   <o>Communication Protocol <0=> TCP <1=> UDP
//   <i> Selecet a protocol for sending data.
#define PROTOCOL       1

#define IWG1_PORT 7071

//------------- <<< end of configuration section >>> -----------------------

#define SENDLEN  24576    /* Number of bytes to send */
#define RECORD   6144
//#define TCP      0
//#define UDP      1

BOOL tick;
U8 socket_tcp;
U8 socket_udp;
U8 Rem_IP[4] = {IP1,IP2,IP3,IP4};
U8 lams_data[SENDLEN];
U8 buffCnt = 0; 
U16 length;
static const U8 N_PER_BUFF = 4;
struct _lamsBuff
{
  U32 beam1[512];
  U32 beam2[512];
  U32 beam3[512];
}; 
struct _lamsBuff lamsBuffer[N_PER_BUFF];

/* Local Function Prototypes */

static void ExtInt0_isr(void) __irq;
/*--------------------------- init ------------------------------------------*/

static void init () {
  /* Add System initialisation code here */

  /* I/O Ports configured as Output (Push-pull) */
  FIO0DIR  = 0x00000000;				//Port 0 32-bit data from FPGA
  FIO0MASK = 0x00000000;
  FIO2DIR  = 0x00000000;
  FIO2MASK = 0x00000000;
  FIO3DIR  = 0x0000003F;
  FIO3MASK = 0x00000020;
  FIO4DIR  = 0x0000001F;
  FIO4MASK = 0x0000003F;	// "1" is output
	PINSEL6  = 0x0000;			// P3.5 = debug
	PINSEL4	 = 0x00100000;	//EINT0
	PINSEL8	 = 0x0000;	    //P4 switch outputs
  PINSEL10 = 0;

  /* Timer 1 as interval timer, reload to 100ms. */
  T1TCR = 1;
  T1MCR = 3;
  T1MR0 = TCNT - 1;
  EXTINT = 0x01;
  EXTMODE = 0x0F;
  EXTPOLAR = 0x00;
  /* Configure VIC for Eint0 interrupt. */
  VICVectAddr14 = (U32) &ExtInt0_isr;
  /* Ethernet Interrupt Enable function. */
  VICIntEnable = 1 << 14;

	FIO3MASK0 = 0x20;
  FIO3SET0 = 0x01; //Set Sel 000 Clear 0 Rd. 0
  FIO3SET0 = 0x0B; //Set Clear  Set Rd. Set Sel 010
  FIO3SET0 = 0x00; //Clear 0 Rd. 0 Sel 000

}

/*--------------------------- timer_poll ------------------------------------*/

static void timer_poll () {
  /* System tick timer running in poll mode */

  if (T1IR & 1) {
    T1IR = 1;
    /* Timer tick every 100 ms */
    timer_tick ();
    tick = __TRUE;
  }
}

/*--------------------------- Process received data  ------------------------*/

void procrec (U8 *buf) {
  U8 tas;

  tas = buf[8];
/*
	if (tas < 78) {
// Set switches for 0 MHz
    FIO4PIN1 = 0x00;
  }
	else if (tas < 156) {
// Set switches for 100 MHz
  }
  else {
// Set switches for 200 MHz\
  }
*/
}

/*--------------------------- UDP socket ------------------------------------*/

U16 udp_callback (U8 soc, U8 *rip, U16 rport, U8 *buf, U16 len) {
  /* This function is called by the UDP module when UDP packet is received. */

  /* Make a reference to suppress compiler warnings. */
  buf  = buf;
  rip  = rip;
  rport= rport;
  len  = len;
  if (soc != socket_udp) {
    /* Check if this is the socket we are connected to */
    return (0);
  }
  procrec(buf);

  return (0);
}


/*--------------------------- TCP socket ------------------------------------*/

U16 tcp_callback (U8 soc, U8 evt, U8 *ptr, U16 par) {
  /* This function is called by the TCP module on TCP event */
  /* Check the Net_Config.h for possible events.            */

  /* Make a reference to suppress compiler warnings. */
  soc = soc;
  par = par;
  evt = evt;
  ptr = ptr;
  return (0);
}


/*--------------------------- TCP send --------------------------------------*/

void send_data (U8 *buf) {
  U8 *sendbuf, flag;
//  char ascii[] = "0123456789ABCDEF";
  char ascii[] = "Hello";

	length = strlen(ascii);
  /* UDP */
  if (socket_udp != 0) {
    /* Start Connection */
    sendbuf = udp_get_buf (length);
//		memcpy(sendbuf,buf,length);
		strcpy((char *)sendbuf, ascii);
    flag = udp_send (socket_udp, Rem_IP, PORT_NUM, sendbuf, length);
		if (flag == __TRUE) {
 		  FIO3MASK0 = 0xDF;
  		FIO3SET0 = 0x20;		 //toggle debug
  		FIO3CLR0 = 0x20;
  		FIO3SET0 = 0x20;		 //toggle debug
  		FIO3CLR0 = 0x20;
  		FIO3SET0 = 0x20;		 //toggle debug
  		FIO3CLR0 = 0x20;
  		FIO3SET0 = 0x20;		 //toggle debug
  		FIO3CLR0 = 0x20;
  		FIO3SET0 = 0x20;		 //toggle debug
  		FIO3CLR0 = 0x20;
  		FIO3SET0 = 0x20;		 //toggle debug
  		FIO3CLR0 = 0x20;
  		FIO3SET0 = 0x20;		 //toggle debug
  		FIO3CLR0 = 0x20;
	  	FIO3MASK0 = 0x20;
		}
		if (flag == __FALSE) {
 		  FIO3MASK0 = 0xDF;
  		FIO3SET0 = 0x20;		 //toggle debug
  		FIO3CLR0 = 0x20;
  		FIO3SET0 = 0x20;		 //toggle debug
  		FIO3CLR0 = 0x20;
	  	FIO3MASK0 = 0x20;
		}

  }

  /* TCP */
/*
  if (socket_tcp != 0) {    // Start Connection 

    switch (tcp_get_state(socket_tcp)) {
      case TCP_STATE_FREE:
      case TCP_STATE_CLOSED:
        tcp_connect (socket_tcp, Rem_IP, PORT_NUM, 0);
        break;
      case TCP_STATE_CONNECT:
        if (tcp_check_send (socket_tcp) == __TRUE) {
          sendbuf = tcp_get_buf(length);
					memcpy(sendbuf,buf,length);
          tcp_send (socket_tcp, sendbuf, length);
        }
        break;
    }
  }
*/
}


/*--------------------------- main ------------------------------------------*/

int main (void) {
  /* Main Thread of the TcpNet */
//  U8 protocol;
  U8 iwg1_socket, flag;

  init ();
//  init_display ();
  init_TcpNet ();

  /* Initialize UDP Socket and start listening */
														 /*
  iwg1_socket = udp_get_socket (0, UDP_OPT_SEND_CS | UDP_OPT_CHK_CS, udp_callback);
  if (iwg1_socket != 0) {
    udp_open (iwg1_socket, IWG1_PORT);
  }
														*/
  socket_udp = udp_get_socket (0, UDP_OPT_SEND_CS | UDP_OPT_CHK_CS, udp_callback);
  if (socket_udp != 0)
    flag = udp_open (socket_udp, PORT_NUM);


/*
  protocol = PROTOCOL;
  switch (protocol) {
    case TCP:
      socket_tcp = tcp_get_socket (TCP_TYPE_CLIENT, 0, 10, tcp_callback);
      break;
    case UDP:
      socket_udp = udp_get_socket (0, UDP_OPT_SEND_CS | UDP_OPT_CHK_CS, udp_callback);
      if (socket_udp != 0) {
        udp_open (socket_udp, PORT_NUM);
      }
      break;
  }
*/

  while (1) {
	  if (++buffCnt >= N_PER_BUFF) {
      timer_poll ();
      main_TcpNet ();
		  length = RECORD * buffCnt;
      if (tick == __TRUE) {
//  		  FIO3MASK0 = 0xDF;
//	  		FIO3SET0 = 0x20;		 //toggle debug
        send_data((U8 *) lamsBuffer);
		  	buffCnt = 0; 
        tick = __FALSE;
//	  		FIO3CLR0 = 0x20;
//		  	FIO3MASK0 = 0x20;
  	  }
		}
  }
}

/*--------------------------- interrupt_eint0 ----------------------------*/

static void ExtInt0_isr(void) __irq {
  int i;

	  /* Ethernet Interrupt Disable function. */
  VICIntEnClr = 1 << 14;
/*	
  FIO3MASK0 = 0x20;
  FIO3SET0 = 0x03; //Set Clear and Rd. Ram address is reset
  for(i=0;i<512;i++) {
	  FIO3SET0 = 0x04; //Set Sel 001 Clear 0 Rd. 0
    FIO3SET0 = 0x06; //Set Sel 001, Clear 0, Rd. 1
  	lamsBuffer[buffCnt].beam1[i] = FIO0PIN;
  	FIO3SET0 = 0x08; //Clear 0 Rd. 0 Sel 010
  	FIO3SET0 = 0x0A; //Set Rd.
  	lamsBuffer[buffCnt].beam2[i] = FIO0PIN;
  	FIO3SET0 = 0x10; //Clear 0 Rd 0 Sel 100
    FIO3SET0 = 0x12; //Set Rd.
    lamsBuffer[buffCnt].beam3[i] = FIO0PIN;
  	FIO3SET0 = 0x1C; //Clear 0 Rd 0 Sel 111
    FIO3SET0 = 0x1E; //Set Rd. and increment ram address
  }	 	
*/
  EXTINT = 0x01;
  /* EMAC Ethernet Controller Interrupt function. */
	  /* Acknowledge the interrupt. */
  VICVectAddr = 0;

 /* Ethernet Interrupt Enable function. */
  VICIntEnable = 1 << 14;
	 
}

/*----------------------------------------------------------------------------
 * end of file
 *---------------------------------------------------------------------------*/
