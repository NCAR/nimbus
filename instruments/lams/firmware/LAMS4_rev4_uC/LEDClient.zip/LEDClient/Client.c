/*----------------------------------------------------------------------------
 *      RL-ARM - TCPnet
 *----------------------------------------------------------------------------
 *      Name:    CLIENT.C
 *      Purpose: LED Control Client demo example
 *----------------------------------------------------------------------------
 *      This code is part of the RealView Run-Time Library.
 *      Copyright (c) 2004-2011 KEIL - An ARM Company. All rights reserved.
 *---------------------------------------------------------------------------*/

#include <RTL.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <LPC23xx.H>                    /* LPC23xx definitions               */
#include <NET_CONFIG.H>

#define MCLK 48000000                         /* Master Clock 48 MHz         */
#define TCLK      100                         /* Timer Clock rate 10/s       */
#define TCNT (MCLK/TCLK/4)                    /* Timer Counts                */

#define MY_IP localm[NETIF_ETH].IpAdr
#define DHCP_TOUT   50                        /* DHCP timeout 5 seconds      */


//-------- <<< Use Configuration Wizard in Context Menu >>> -----------------

//   <h>Remote IP Address
//   ====================
#define IP1            192
#define IP2            168
#define IP3            184
#define IP4            1

//   <o>Remote Port <1-65535>
//   <i> Do not set number of port too small,
//   <i> maybe it is already used.
//   <i> Default: 1001
#define PORT_NUM       41002
#define IWG1_PORT       7071
//   <o>Communication Protocol <0=> TCP <1=> UDP
//   <i> Selecet a protocol for sending data.
#define PROTOCOL       1

//   <o>LED Blinking speed <1-100>
//   <i> Blinking speed = SPEED * 100ms
//   <i> Default: 2


//------------- <<< end of configuration section >>> -----------------------

#define SENDLEN  1450    /* Number of bytes to send */
#define RECORD   6144
#define BuffCnt  2
//#define TCP      0
//#define UDP      1

BOOL tick;
static BOOL interrupt;
U8 socket_tcp;
U8 socket_udp;
U8 iwg1_socket;
U8 Rem_IP[4] = {IP1,IP2,IP3,IP4};
U32  dhcp_tout; //KRB

U8 lams_data[SENDLEN];
U16 length;
U8 bufnum;
//U32 tcount1, tcount2, tcount3;
static U32 count;
static const U16 SEND_LEN = 1450;
struct _lamsBuff
{
//  U16 test[725];
  U32 beam1[514];
  U32 beam2[514];
  U32 beam3[514];
  U32 beam4[514];
}; 
struct _lamsBuff lamsBuffer[BuffCnt];

/* Local Function Prototypes */

static void ExtInt0_isr(void) __irq;

static void dhcp_check () {

  /* Monitor DHCP IP address assignment. */

  if (tick == __FALSE || dhcp_tout == 0) {
    return;
  }
#ifdef RTX_KERNEL
  tick = __FALSE;
#endif
  //if (mem_test (&MY_IP, 0, IP_ADRLEN) == __FALSE && !(dhcp_tout & 0x80000000)) {
    /* Success, DHCP has already got the IP address. */
//    dhcp_tout = 0;
  //}
  if (--dhcp_tout == 0) {
    /* A timeout, disable DHCP and use static IP address. */
    dhcp_disable ();
    dhcp_tout = 30 | 0x80000000;
    return;
  }
  if (dhcp_tout == 0x80000000) {
    dhcp_tout = 0;
  }

}

/*--------------------------- init ------------------------------------------*/

static void init () {
/*  
  char ascii1[] = "1111";
  char ascii2[] = "3333";
  char ascii3[] = "7777";
*/
  /* I/O Ports configured as Output (Push-pull) */
  FIO0DIR  = 0x00000000;				//Port 0 32-bit data from FPGA
  FIO0MASK = 0x00000000;
  FIO2DIR  = 0x00000000;
  FIO2MASK = 0x00000000;
  FIO3DIR  = 0x0000007F;
  FIO3MASK = 0x00000000;
  FIO4DIR  = 0x000000FF;  // "1" is output
  FIO4MASK = 0x00000000;	 
//  PINSEL0  = 0x00000000;
//  PINSEL1  = 0x00000000;
  PINSEL6    = 0x0000;			// P3.5 = debug
  PINSEL4	 = 0x00100000;	//EINT0
  PINSEL8	 = 0x00000000;	//P4 switch outputs
  PINSEL10 = 0;

  bufnum = 0;
  /* Timer 1 as interval timer, reload to 100ms. */
  T1TCR = 1;
  T1MCR = 3;
  T1MR0 = TCNT - 1;
  EXTINT = 0x01;
  EXTMODE = 0x01;
  EXTPOLAR = 0x00;

/* Configure UART1 for 115200 baud. */
  PINSEL0 = 0x40000000;                      /* Enable TxD1 pin              */
  PINSEL1 = 0x00000001;                      /* Enable RxD1 pin              */
  U1LCR = 0x83;                              /* 8 bits, no Parity, 1 Stop bit*/
  U1DLL = 3;                                 /* for 12MHz PCLK Clock         */
  U1FDR = 0x67;                              /* Fractional Divider           */
  U1LCR = 0x03;                              /* DLAB = 0                     */


  while ((FIO3PIN0 & 0x80) == 0){}  
   	FIO3CLR0 = 0x40;
    FIO3SET0 = 0x40;		 //toggle fpga reset
	FIO3SET0 = 0x40;
 //  	FIO3CLR0 = 0x40;

   
  /* Configure VIC for Eint0 interrupt. */
  VICVectAddr14 = (U32) &ExtInt0_isr;
  /* Ethernet Interrupt Enable function. */
  VICIntEnable = 1 << 14;
  lamsBuffer[0].beam1[0] = 0x11111111;
  lamsBuffer[0].beam2[0] = 0x33333333;
  lamsBuffer[0].beam3[0] = 0x77777777;
  lamsBuffer[0].beam4[0] = 0x55555555;
  lamsBuffer[1].beam1[0] = 0x11111111;
  lamsBuffer[1].beam2[0] = 0x33333333;
  lamsBuffer[1].beam3[0] = 0x77777777;
  lamsBuffer[1].beam4[0] = 0x55555555;
/*
  strcpy((char *)&lamsBuffer[0].beam1[0],ascii1);
  strcpy((char *)&lamsBuffer[0].beam2[0],ascii2);
  strcpy((char *)&lamsBuffer[0].beam3[0],ascii3);
  strcpy((char *)&lamsBuffer[1].beam1[0],ascii1);
  strcpy((char *)&lamsBuffer[1].beam2[0],ascii2);
  strcpy((char *)&lamsBuffer[1].beam3[0],ascii3);
*/  
  count = 0;
/*
  while(1){
    FIO3SET0 = 0x20;		 //toggle debug	
    FIO3CLR0 = 0x20;
	}
*/	
}

/*--------------------------- timer_poll ------------------------------------*/

static void timer_poll () {
  /* System tick timer running in poll mode */

  if (T1IR & 1) {
    T1IR = 1;
    /* Timer tick every 100 ms */
    timer_tick ();
    tick = __TRUE;
  }
}
/*--------------------------- fputc -----------------------------------------*/

int fputc (int ch, FILE *f)  {
  /* Debug output to serial port. */

  if (ch == '\n')  {
    while (!(U1LSR & 0x20));
    U1THR = '\r';                            /* output CR                    */
  }
  while (!(U1LSR & 0x20));
  return (U1THR = ch);
}


/*--------------------------- Process received data  ------------------------*/
U8 tas_save = 0; // Add by JKC 12/20/2016

void procrec (U8 *buf) {
  int tas;
  char *p = (char *)buf, i;

  for(i=0;i<9;i++) {
    p=strchr(p,',') + 1;
  }
  tas = (int)atoi(p);
  if (tas != tas_save) {	//Update only if tas changes, Added by JKC 12/20/2016
	if (tas < 78) {
// Set switches for 0 MHz
    FIO4CLR0 = 0xFF;
  }
	else if ((tas < 95) && (tas >= 78)) {
// Set switches for ch #2 100 MHz 
    FIO4CLR0 = 0xFF;
    FIO4SET0 = 0x04;
  }	else if ((tas < 156) && (tas >= 95)) {
// Set switches for all ch # 100 MHz
    FIO4CLR0 = 0xFF;
    FIO4SET0 = 0x55;
  }
	else if ((tas < 190) && (tas >= 156)) {
// Set switches for ch# 3 200 MHz
    FIO4CLR0 = 0xFF;
    FIO4SET0 = 0x59;
  }  else {
// Set switches for all ch # 200 MHz
    FIO4CLR0 = 0xFF;
    FIO4SET0 = 0xAA;
  }
  }
  tas_save = tas; // Added by JKC 12/20/2016
}

/*--------------------------- UDP socket ------------------------------------*/
U16 udp_callback (U8 soc, U8 *rip, U16 rport, U8 *buf, U16 len) {
  /* This function is called by the UDP module when UDP packet is received. */

  /* Make a reference to suppress compiler warnings. */

  buf  = buf;
  rip  = rip;
  rport= rport;
  len  = len;
//  soc  = soc;
//  return (0);
  if (soc != iwg1_socket) {
    /* Check if this is the socket we are connected to */
    return (0);
  }
  procrec(buf);

  return (0);
}


/*--------------------------- TCP socket ------------------------------------*/

U16 tcp_callback (U8 soc, U8 evt, U8 *ptr, U16 par) {
  /* This function is called by the TCP module on TCP event */
  /* Check the Net_Config.h for possible events.            */

  /* Make a reference to suppress compiler warnings. */
  soc = soc;
  par = par;
  evt = evt;
  ptr = ptr;
  return (0);
}


/*--------------------------- TCP send --------------------------------------*/
void send_data (U8 *buf) {
  U8 *sendbuf;
  U8 i;
  U16 len = sizeof(lamsBuffer[0].beam1);
//  U16 len = sizeof(lamsBuffer[0]);
  U16 send_len, pos;
  static BOOL flag;
//  char ascii[] = "0123456789ABCDEF";
//  char ascii[] = "Hello";

//	length = strlen(ascii);
//  len = len/3;
  pos = 0;
  if (socket_udp != 0) {
//    for (i=0; i < 3; i++) {
      while (pos < len ) {

        if ((len-pos) > SEND_LEN) send_len = SEND_LEN;
        else send_len = len-pos;

        sendbuf = udp_get_buf (send_len );
   	  	memcpy(sendbuf,&buf[pos],send_len);
        flag = udp_send(socket_udp, Rem_IP, PORT_NUM, sendbuf, send_len);
        pos += send_len;
      }  
//    }
  }
	if (flag == __TRUE) {
		for(i = 0; i < 84; i++) {
      FIO3SET0 = 0x20;		 //toggle debug
		}		
    FIO3CLR0 = 0x20;
	}	

//		strcpy((char *)sendbuf, ascii);

  /* TCP */
/*
  if (socket_tcp != 0) {    // Start Connection 

    switch (tcp_get_state(socket_tcp)) {
      case TCP_STATE_FREE:
      case TCP_STATE_CLOSED:
        tcp_connect (socket_tcp, Rem_IP, PORT_NUM, 0);
        break;
      case TCP_STATE_CONNECT:
        if (tcp_check_send (socket_tcp) == __TRUE) {
          sendbuf = tcp_get_buf(length);
					memcpy(sendbuf,buf,length);
          tcp_send (socket_tcp, sendbuf, length);
        }
        break;
    }
  }
*/
}



/*--------------------------- main ------------------------------------------*/

int main (void) {
  /* Main Thread of the TcpNet */
//  U8 protocol;

  init ();

  init_TcpNet ();

  /* Initialize UDP Socket and start listening */
														 
  iwg1_socket = udp_get_socket (0, UDP_OPT_SEND_CS | UDP_OPT_CHK_CS, udp_callback);
  if (iwg1_socket != 0) {
    udp_open (iwg1_socket, IWG1_PORT);
  }
														
  socket_udp = udp_get_socket (0, UDP_OPT_SEND_CS | UDP_OPT_CHK_CS, udp_callback);
  if (socket_udp != 0)
    udp_open (socket_udp, PORT_NUM);


/*
  protocol = PROTOCOL;
  switch (protocol) {
    case TCP:
      socket_tcp = tcp_get_socket (TCP_TYPE_CLIENT, 0, 10, tcp_callback);
      break;
    case UDP:
      socket_udp = udp_get_socket (0, UDP_OPT_SEND_CS | UDP_OPT_CHK_CS, udp_callback);
      if (socket_udp != 0) {
        udp_open (socket_udp, PORT_NUM);
      }
      break;
  }
*/
  dhcp_tout = DHCP_TOUT;

//  wait = __FALSE; 
  interrupt = __FALSE;

  while (1) {

    if(interrupt == __TRUE) {
      timer_poll ();
      main_TcpNet ();
      dhcp_check();

 //   if (tick == __TRUE) {
      send_data((U8 *)lamsBuffer[bufnum].beam1);
      send_data((U8 *)lamsBuffer[bufnum].beam2);
      send_data((U8 *)lamsBuffer[bufnum].beam3);
      send_data((U8 *)lamsBuffer[bufnum].beam4);
      interrupt = __FALSE;
//    if (bufnum == 0) send_data((U8 *)&lamsBuffer[0]);
//    else send_data((U8 *)&lamsBuffer[1]);
      if (bufnum == 0) bufnum = 1;
      else bufnum = 0;	
//      tick = __FALSE;
//    }

    }
  }
}

/*--------------------------- interrupt_eint0 ----------------------------*/

static void ExtInt0_isr(void) __irq {
  int i;
	  /* Ethernet Interrupt Disable function. */
  VICIntEnClr = 1 << 14;


  FIO3CLR0 = 0x1F; //Reset all
  FIO3SET0 = 0x01; //Set Sel 010 Clear 1 Rd. 0
  FIO3SET0 = 0x03; //Set Sel 010 Clear 1 Rd. 1
  FIO3CLR0 = 0x1F; //Reset all

  FIO3CLR0 = 0x1F; //reset all
  FIO3SET0 = 0x04; //Set Sel 001 Clear 0 Rd. 0
  FIO3SET0 = 0x06; //Set Sel 001, Clear 0, Rd. 1
  FIO3CLR0 = 0x1F; //reset all
  FIO3SET0 = 0x04; //Set Sel 001 Clear 0 Rd. 0
  FIO3SET0 = 0x06; //Set Sel 001, Clear 0, Rd. 1
  FIO3CLR0 = 0x1F; //reset Rd.
  FIO3SET0 = 0x10; //Clear 0 Rd 0 Sel 100 
  FIO3SET0 = 0x12; //Set Rd. 
 
  for(i=2;i<514;i++) {

    FIO3CLR0 = 0x1F; //reset all
	FIO3SET0 = 0x04; //Set Sel 001 Clear 0 Rd. 0
    FIO3SET0 = 0x06; //Set Sel 001, Clear 0, Rd. 1
  	lamsBuffer[bufnum].beam1[i] = IOPIN0;

    FIO3CLR0 = 0x1F; //Clr Rd. Sel 010
  	FIO3SET0 = 0x08; //Clear 0 Rd. 0 Sel 010 
  	FIO3SET0 = 0x0A; //Set Rd.
  	lamsBuffer[bufnum].beam2[i] = IOPIN0;

    FIO3CLR0 = 0x1F; //reset Rd.
  	FIO3SET0 = 0x0C; //Clear 0 Rd 0 Sel 011 
    FIO3SET0 = 0x0E; //Set Rd. 
    lamsBuffer[bufnum].beam3[i] = IOPIN0;

    FIO3CLR0 = 0x1F; //reset Rd.
  	FIO3SET0 = 0x10; //Clear 0 Rd 0 Sel 100 
    FIO3SET0 = 0x12; //Set Rd. 
    lamsBuffer[bufnum].beam4[i] = IOPIN0;
   
  }	 
	lamsBuffer[bufnum].beam1[1] = count;
	lamsBuffer[bufnum].beam2[1] = count;
	lamsBuffer[bufnum].beam3[1] = count;
	lamsBuffer[bufnum].beam4[1] = count++;
  
  EXTINT = 0x01;
  interrupt = __TRUE;
  /* EMAC Ethernet Controller Interrupt function. */
	  /* Acknowledge the interrupt. */
  VICVectAddr = 0;

 /* Ethernet Interrupt Enable function. */
  VICIntEnable = 1 << 14;	 
}

/*----------------------------------------------------------------------------
 * end of file
 *---------------------------------------------------------------------------*/

