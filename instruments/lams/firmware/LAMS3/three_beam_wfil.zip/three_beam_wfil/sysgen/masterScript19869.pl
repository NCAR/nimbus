
open(PIDFILE, '> pidfile.txt') || die 'Couldn\'t write process ID to file.';
print PIDFILE "$$\n";
close(PIDFILE);

eval {
  # Call script(s).
  my $instrs;
  my $results = [];
$ENV{'SYSGEN'} = 'C:/xilinx/10.1/DSP_Tools/sysgen';
  use Sg;
  $instrs = {
    'HDLCodeGenStatus' => 0.0,
    'base_system_period_hardware' => 5.0,
    'base_system_period_simulink' => 1.0E-5,
    'block_icon_display' => 'Default',
    'block_type' => 'sysgen',
    'block_version' => '9.1.01',
    'ce_clr' => 0.0,
    'clock_loc' => '',
    'clock_wrapper' => 'Clock Enables',
    'clocksGcd' => 1.0,
    'compilation' => 'HDL Netlist',
    'compilation_lut' => {
      'keys' => [ 'HDL Netlist', ],
      'values' => [ 'target1', ],
    },
    'core_generation' => 1.0,
    'core_generation_sgadvanced' => '',
    'coregenPartFamily' => 'virtex5',
    'coregen_part_family' => 'Virtex5',
    'createTestbench' => 0,
    'dbl_ovrd' => -1.0,
    'dbl_ovrd_sgadvanced' => '',
    'dcm_input_clock_period' => 100.0,
    'deprecated_control' => 'off',
    'deprecated_control_sgadvanced' => '',
    'design' => 'three_beam_wfil',
    'design_full_path' => 'C:\\my_work\\three_beam_wfil\\three_beam_wfil.mdl',
    'device' => 'xc5vsx50t-1ff665',
    'directory' => 'C:/my_work/three_beam_wfil',
    'disregard_netlist_subystem_handles' => undef,
    'eval_field' => '0',
    'fileDeliveryDefaults' => [
      [
        '(?i)\\.vhd$',
        { 'fileName' => 'C:/my_work/three_beam_wfil/sysgen/perl_results.vhd', },
      ],
      [
        '(?i)\\.v$',
        { 'fileName' => 'C:/my_work/three_beam_wfil/sysgen/perl_results.v', },
      ],
    ],
    'fxdptinstalled' => 0.0,
    'gcc_exe' => 'c:/xilinx/10.1/ise/gnu/MinGW/2.0.0-3/nt/bin/gcc.exe',
    'generateUsing71FrontEnd' => 1,
    'has_advanced_control' => '0',
    'hdlDir' => 'C:/xilinx/10.1/DSP_Tools/common/bin/../../sysgen/hdl',
    'hdlKind' => 'vhdl',
    'incr_netlist' => 'off',
    'incr_netlist_sgadvanced' => '',
    'infoedit' => ' System Generator',
    'ise_full_version' => '10.1.03i',
    'ise_version' => '10.1i',
    'master_sysgen_token_handle' => 2381.0003662109375,
    'matlab' => 'C:/MATLAB/R2006b',
    'matlabJavaDirectory' => 'C:/MATLAB/R2006b/sys/java/jre/win32/jre1.4.2/bin',
    'matlabPerlDirectory' => 'C:/MATLAB/R2006b/sys/perl/win32/bin/',
    'mdlHandle' => 2331.0047607421875,
    'mdlPath' => 'C:/my_work/three_beam_wfil/three_beam_wfil.mdl',
    'modelDiagnostics' => [
      {
        'count' => 222.0,
        'isMask' => 0.0,
        'type' => 'three_beam_wfil Total blocks',
      },
      {
        'count' => 3.0,
        'isMask' => 0.0,
        'type' => 'Constant',
      },
      {
        'count' => 4.0,
        'isMask' => 0.0,
        'type' => 'DiscretePulseGenerator',
      },
      {
        'count' => 6.0,
        'isMask' => 0.0,
        'type' => 'From',
      },
      {
        'count' => 6.0,
        'isMask' => 0.0,
        'type' => 'Goto',
      },
      {
        'count' => 20.0,
        'isMask' => 0.0,
        'type' => 'Inport',
      },
      {
        'count' => 16.0,
        'isMask' => 0.0,
        'type' => 'Outport',
      },
      {
        'count' => 128.0,
        'isMask' => 0.0,
        'type' => 'S-Function',
      },
      {
        'count' => 1.0,
        'isMask' => 0.0,
        'type' => 'Step',
      },
      {
        'count' => 8.0,
        'isMask' => 0.0,
        'type' => 'SubSystem',
      },
      {
        'count' => 30.0,
        'isMask' => 0.0,
        'type' => 'Terminator',
      },
      {
        'count' => 3.0,
        'isMask' => 1.0,
        'type' => 'Sine Wave',
      },
      {
        'count' => 6.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Adder/Subtractor Block',
      },
      {
        'count' => 6.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Arithmetic Relational Operator Block',
      },
      {
        'count' => 3.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Bit Slice Extractor Block',
      },
      {
        'count' => 1.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Black Box Block',
      },
      {
        'count' => 24.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Constant Block Block',
      },
      {
        'count' => 3.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Counter Block',
      },
      {
        'count' => 28.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Delay Block',
      },
      {
        'count' => 6.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Dual Port Random Access Memory Block',
      },
      {
        'count' => 3.0,
        'isMask' => 1.0,
        'type' => 'Xilinx FDATool Interface Block',
      },
      {
        'count' => 3.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Fast Fourier Transform 6.0 Block',
      },
      {
        'count' => 3.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Finite Impulse Response Filter Block',
      },
      {
        'count' => 7.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Gateway In Block',
      },
      {
        'count' => 5.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Gateway Out Block',
      },
      {
        'count' => 1.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Inverter Block',
      },
      {
        'count' => 1.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Logical Block Block',
      },
      {
        'count' => 6.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Multiplier Block',
      },
      {
        'count' => 12.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Register Block',
      },
      {
        'count' => 2.0,
        'isMask' => 1.0,
        'type' => 'Xilinx System Generator Block',
      },
      {
        'count' => 1.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Toolbar Block',
      },
      {
        'count' => 3.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Type Converter Block',
      },
      {
        'count' => 3.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Type Reinterpreter Block',
      },
    ],
    'myxilinx' => '',
    'num_sim_cycles' => 'Inf',
    'package' => 'ff665',
    'part' => 'xc5vsx50t',
    'partFamily' => 'virtex5',
    'port_data_types_enabled' => 1.0,
    'preserveHierarchy' => 0.0,
    'preserve_hierarchy' => 0.0,
    'provideGlobalCEClr' => 0.0,
    'report_true_rates' => 0.0,
    'run_coregen' => 'off',
    'run_coregen_sgadvanced' => '',
    'sample_time_colors_enabled' => 0.0,
    'sg_blockgui_xml' => '',
    'sg_icon_stat' => '51,50,-1,-1,red,beige,0,07734',
    'sg_list_contents' => '',
    'sg_mask_display' => 'fprintf(\'\',\'COMMENT: begin icon graphics\');
patch([0 51 51 0 ],[0 0 50 50 ],[0.93 0.92 0.86]);
patch([12 4 16 4 12 25 29 33 47 36 25 17 29 17 25 36 47 33 29 25 12 ],[5 13 25 37 45 45 41 45 45 34 45 37 25 13 5 16 5 5 9 5 5 ],[0.6 0.2 0.25]);
plot([0 0 51 51 0 ],[0 50 50 0 0 ]);
fprintf(\'\',\'COMMENT: end icon graphics\');
fprintf(\'\',\'COMMENT: begin icon text\');
fprintf(\'\',\'COMMENT: end icon text\');
',
    'sggui_pos' => '-1,-1,-1,-1',
    'simulation_island_subsystem_handle' => 2331.0047607421875,
    'simulation_status' => 0.0,
    'simulink_accelerator_running' => 0.0,
    'simulink_debugger_running' => 0.0,
    'simulink_period' => '1/100000',
    'speed' => '-1',
    'startTime' => '0.0',
    'start_time' => 0.0,
    'stopTime' => 'inf',
    'synthesisTool' => 'XST',
    'synthesis_language' => 'vhdl',
    'synthesis_tool' => 'XST',
    'synthesis_tool_sgadvanced' => '',
    'sysclk_period' => '5',
    'sysgen' => 'C:/xilinx/10.1/DSP_Tools/common/bin/../../sysgen',
    'sysgenTokenSettings' => {
      'settings' => {
        'base_system_period_hardware' => 5.0,
        'base_system_period_simulink' => 1.0E-5,
        'block_icon_display' => 'Default',
        'block_type' => 'sysgen',
        'block_version' => '9.1.01',
        'ce_clr' => 0.0,
        'clock_loc' => '',
        'clock_wrapper' => 'Clock Enables',
        'compilation' => 'HDL Netlist',
        'compilation_lut' => {
          'keys' => [ 'HDL Netlist', ],
          'values' => [ 'target1', ],
        },
        'core_generation' => 1.0,
        'core_generation_sgadvanced' => '',
        'coregen_part_family' => 'Virtex5',
        'dbl_ovrd' => -1.0,
        'dbl_ovrd_sgadvanced' => '',
        'dcm_input_clock_period' => 100.0,
        'deprecated_control' => 'off',
        'deprecated_control_sgadvanced' => '',
        'directory' => 'C:/my_work/three_beam_wfil',
        'eval_field' => '0',
        'has_advanced_control' => '0',
        'incr_netlist' => 'off',
        'incr_netlist_sgadvanced' => '',
        'infoedit' => ' System Generator',
        'master_sysgen_token_handle' => 2381.0003662109375,
        'package' => 'ff665',
        'part' => 'xc5vsx50t',
        'preserve_hierarchy' => 0.0,
        'run_coregen' => 'off',
        'run_coregen_sgadvanced' => '',
        'sg_blockgui_xml' => '',
        'sg_icon_stat' => '51,50,-1,-1,red,beige,0,07734',
        'sg_list_contents' => '',
        'sg_mask_display' => 'fprintf(\'\',\'COMMENT: begin icon graphics\');
patch([0 51 51 0 ],[0 0 50 50 ],[0.93 0.92 0.86]);
patch([12 4 16 4 12 25 29 33 47 36 25 17 29 17 25 36 47 33 29 25 12 ],[5 13 25 37 45 45 41 45 45 34 45 37 25 13 5 16 5 5 9 5 5 ],[0.6 0.2 0.25]);
plot([0 0 51 51 0 ],[0 50 50 0 0 ]);
fprintf(\'\',\'COMMENT: end icon graphics\');
fprintf(\'\',\'COMMENT: begin icon text\');
fprintf(\'\',\'COMMENT: end icon text\');
',
        'sggui_pos' => '-1,-1,-1,-1',
        'simulation_island_subsystem_handle' => 2331.0047607421875,
        'simulink_period' => '1/100000',
        'speed' => '-1',
        'synthesis_language' => 'vhdl',
        'synthesis_tool' => 'XST',
        'synthesis_tool_sgadvanced' => '',
        'sysclk_period' => '5',
        'testbench' => 0,
        'testbench_sgadvanced' => '',
        'trim_vbits' => 1.0,
        'trim_vbits_sgadvanced' => '',
        'xilinx_device' => 'xc5vsx50t-1ff665',
        'xilinxfamily' => 'virtex5',
      },
    },
    'systemClockPeriod' => 5.0,
    'tempdir' => 'C:/DOCUME~1/spowart/LOCALS~1/Temp',
    'testbench' => 0,
    'testbench_sgadvanced' => '',
    'tmpDir' => 'C:/my_work/three_beam_wfil/sysgen',
    'trim_vbits' => 1.0,
    'trim_vbits_sgadvanced' => '',
    'use_strict_names' => 1,
    'user_tips_enabled' => 0.0,
    'using71Netlister' => 1,
    'verilog_files' => [
      { 'source' => 'conv_pkg.v', },
      { 'source' => 'synth_reg.v', },
      { 'source' => 'synth_reg_w_init.v', },
      { 'source' => 'convert_type.v', },
      { 'source' => 'xlpersistentdff.ngc', },
    ],
    'version' => '10.1.3.1386',
    'vhdl_files' => [
      { 'source' => 'conv_pkg.vhd', },
      { 'source' => 'synth_reg.vhd', },
      { 'source' => 'synth_reg_w_init.vhd', },
      { 'source' => 'xlpersistentdff.ngc', },
    ],
    'vsimtime' => 'Inf ns',
    'xilinx' => 'c:/xilinx/10.1/ise',
    'xilinx_device' => 'xc5vsx50t-1ff665',
    'xilinxfamily' => 'virtex5',
  };
  push(@$results, &Sg::setAttributes($instrs));
  use SgDeliverFile;
  $instrs = {
    'collaborationName' => 'conv_pkg.vhd',
    'sourceFile' => 'hdl/conv_pkg.vhd',
    'templateKeyValues' => {},
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'collaborationName' => 'synth_reg.vhd',
    'sourceFile' => 'hdl/synth_reg.vhd',
    'templateKeyValues' => {},
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'collaborationName' => 'synth_reg_w_init.vhd',
    'sourceFile' => 'hdl/synth_reg_w_init.vhd',
    'templateKeyValues' => {},
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'collaborationName' => 'xlpersistentdff.ngc',
    'sourceFile' => 'hdl/xlpersistentdff.ngc',
    'templateKeyValues' => {},
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'abd5a4a2dd48aec8f967b6f2800cbb49',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
  signal a_17_32: unsigned((29 - 1) downto 0);
  signal b_17_35: unsigned((36 - 1) downto 0);
  type array_type_op_mem_91_20 is array (0 to (2 - 1)) of unsigned((36 - 1) downto 0);
  signal op_mem_91_20: array_type_op_mem_91_20 := (
    "000000000000000000000000000000000000",
    "000000000000000000000000000000000000");
  signal op_mem_91_20_front_din: unsigned((36 - 1) downto 0);
  signal op_mem_91_20_back: unsigned((36 - 1) downto 0);
  signal op_mem_91_20_push_front_pop_back_en: std_logic;
  type array_type_cout_mem_92_22 is array (0 to (2 - 1)) of unsigned((1 - 1) downto 0);
  signal cout_mem_92_22: array_type_cout_mem_92_22 := (
    "0",
    "0");
  signal cout_mem_92_22_front_din: unsigned((1 - 1) downto 0);
  signal cout_mem_92_22_back: unsigned((1 - 1) downto 0);
  signal cout_mem_92_22_push_front_pop_back_en: std_logic;
  signal prev_mode_93_22_next: unsigned((3 - 1) downto 0);
  signal prev_mode_93_22: unsigned((3 - 1) downto 0);
  signal prev_mode_93_22_reg_i: std_logic_vector((3 - 1) downto 0);
  signal prev_mode_93_22_reg_o: std_logic_vector((3 - 1) downto 0);
  signal cast_69_18: unsigned((37 - 1) downto 0);
  signal cast_69_22: unsigned((37 - 1) downto 0);
  signal internal_s_69_5_addsub: unsigned((37 - 1) downto 0);
  signal internal_s_83_3_convert: unsigned((36 - 1) downto 0);
begin
  a_17_32 <= std_logic_vector_to_unsigned(a);
  b_17_35 <= std_logic_vector_to_unsigned(b);
  op_mem_91_20_back <= op_mem_91_20(1);
  proc_op_mem_91_20: process (clk)
  is
    variable i: integer;
  begin
    if (clk\'event and (clk = \'1\')) then
      if ((ce = \'1\') and (op_mem_91_20_push_front_pop_back_en = \'1\')) then
        for i in 1 downto 1 loop 
          op_mem_91_20(i) <= op_mem_91_20(i-1);
        end loop;
        op_mem_91_20(0) <= op_mem_91_20_front_din;
      end if;
    end if;
  end process proc_op_mem_91_20;
  cout_mem_92_22_back <= cout_mem_92_22(1);
  proc_cout_mem_92_22: process (clk)
  is
    variable i_x_000000: integer;
  begin
    if (clk\'event and (clk = \'1\')) then
      if ((ce = \'1\') and (cout_mem_92_22_push_front_pop_back_en = \'1\')) then
        for i_x_000000 in 1 downto 1 loop 
          cout_mem_92_22(i_x_000000) <= cout_mem_92_22(i_x_000000-1);
        end loop;
        cout_mem_92_22(0) <= cout_mem_92_22_front_din;
      end if;
    end if;
  end process proc_cout_mem_92_22;
  prev_mode_93_22_reg_i <= unsigned_to_std_logic_vector(prev_mode_93_22_next);
  prev_mode_93_22 <= std_logic_vector_to_unsigned(prev_mode_93_22_reg_o);
  prev_mode_93_22_reg_inst: entity work.synth_reg_w_init
    generic map (
      init_index => 2, 
      init_value => b"010", 
      latency => 1, 
      width => 3)
    port map (
      ce => ce, 
      clk => clk, 
      clr => clr, 
      i => prev_mode_93_22_reg_i, 
      o => prev_mode_93_22_reg_o);
  cast_69_18 <= u2u_cast(a_17_32, 0, 37, 0);
  cast_69_22 <= u2u_cast(b_17_35, 0, 37, 0);
  internal_s_69_5_addsub <= cast_69_18 + cast_69_22;
  internal_s_83_3_convert <= std_logic_vector_to_unsigned(convert_type(unsigned_to_std_logic_vector(internal_s_69_5_addsub), 37, 0, xlUnsigned, 36, 0, xlUnsigned, xlRound, xlWrap));
  op_mem_91_20_front_din <= internal_s_83_3_convert;
  op_mem_91_20_push_front_pop_back_en <= \'1\';
  cout_mem_92_22_front_din <= std_logic_vector_to_unsigned("0");
  cout_mem_92_22_push_front_pop_back_en <= \'1\';
  prev_mode_93_22_next <= std_logic_vector_to_unsigned("000");
  s <= unsigned_to_std_logic_vector(op_mem_91_20_back);
end',
      'crippled_entity' => 'is
  port (
    a : in std_logic_vector((29 - 1) downto 0);
    b : in std_logic_vector((36 - 1) downto 0);
    s : out std_logic_vector((36 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'addsub_15975a2b19',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  use SgGenerateCores;
  $instrs = [
    'SELECT Adder_Subtracter Virtex5 Xilinx,_Inc. 10.0',
    '# 10.1.03i',
    'CSET AINIT_Value = 0',
    'CSET A_Type = Signed',
    'CSET A_Width = 29',
    'CSET Add_Mode = Add',
    'CSET B_Constant = false',
    'CSET B_Type = Signed',
    'CSET B_Value = 0',
    'CSET B_Width = 29',
    'CSET Borrow_Sense = Active_Low',
    'CSET Bypass = false',
    'CSET Bypass_CE_Priority = Bypass_Overrides_CE',
    'CSET Bypass_Sense = Active_Low',
    'CSET CE = true',
    'CSET C_In = false',
    'CSET C_Out = false',
    'CSET Implementation = Fabric',
    'CSET Latency = 1',
    'CSET Out_Width = 29',
    'CSET SCLR = false',
    'CSET SINIT = false',
    'CSET SINIT_Value = 0',
    'CSET SSET = false',
    'CSET Sync_CE_Priority = Sync_Overrides_CE',
    'CSET Sync_Ctrl_Priority = Reset_Overrides_Set',
    'CSET component_name = adder_subtracter_virtex5_10_0_3cf46f432850ef09',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '464265a6fd6611eb71e3c17ef5ccc54f',
    'sourceFile' => 'hdl/xladdsubv10_0.vhd',
    'templateKeyValues' => {
      'core_component_def' => '    a: in std_logic_vector(29 - 1 downto 0);
    clk: in std_logic:= \'0\';
    ce: in std_logic:= \'0\';
    s: out std_logic_vector(c_output_width - 1 downto 0);
    b: in std_logic_vector(29 - 1 downto 0)',
      'core_instance_text' => '         a => full_a,
         clk => clk,
         ce => internal_ce,
         s => core_s,
         b => full_b',
      'core_name0' => 'adder_subtracter_virtex5_10_0_3cf46f432850ef09',
      'entity_name.0' => 'xladdsubv10_0',
      'needs_core' => 1,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '13366d021ddc9f5413827bc05cb9e24f',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "1";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((1 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_6293007044',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'c8ac2f8b02c35d537ca2d762269f7a07',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "00000000000000000000000000000000";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_37567836aa',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '86473f04c190c4f764cb27d8b6eb1382',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "00000000000000";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((14 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_068ec526a0',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '33d0bd4da38e5cae4fc9beffbd0ed266',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "0000000000";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((10 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_498bc68c14',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '26c90b101ce1ca8b2f28c242a8215ef7',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "0";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((1 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_963ed6358a',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'c6aa4ab7c6e38a8fd13413ef5b5829ce',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "0111101000";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((10 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_7446c1191a',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '7ca85ba5c64f88656548cae59895ff50',
    'sourceFile' => 'C:/xilinx/10.1/DSP_Tools/sysgen/hdl/xlconvert.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Binary_Counter Virtex5 Xilinx,_Inc. 10.0',
    '# 10.1.03i',
    'CSET ainit_value = 0',
    'CSET ce = true',
    'CSET count_mode = UP',
    'CSET fb_latency = 0',
    'CSET final_count_value = 1',
    'CSET implementation = Fabric',
    'CSET increment_value = 1',
    'CSET latency = 1',
    'CSET load = false',
    'CSET output_width = 10',
    'CSET restrict_count = false',
    'CSET sclr = false',
    'CSET sinit = true',
    'CSET sinit_value = 0',
    'CSET sset = false',
    'CSET sync_ce_priority = Sync_Overrides_CE',
    'CSET sync_threshold_output = false',
    'CSET syncctrlpriority = Reset_Overrides_Set',
    'CSET component_name = binary_counter_virtex5_10_0_1ee993c8ed57b9ce',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '91940f3e629f63fcaafe323242b3b4c8',
    'sourceFile' => 'hdl/xlcounter_limit.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      clk: in std_logic;
      ce: in std_logic;
      SINIT: in std_logic;
      q: out std_logic_vector(op_width - 1 downto 0)',
      'core_instance_text' => '        clk => clk,
        ce => core_ce,
        SINIT=> core_sinit,
        q => op_net',
      'core_name0' => 'binary_counter_virtex5_10_0_1ee993c8ed57b9ce',
      'entity_name.0' => 'xlcounter_limit',
      'needs_core' => 1,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Distributed_Arithmetic_FIR_Filter Virtex4 Xilinx,_Inc. 9.0',
    '# 10.1.03i',
    'CSET clock_cycles_per_sample = 1',
    'CSET coefficient_data_type = signed',
    'CSET coefficient_file = [
 Radix=10;
Coefdata = -707 -552 -703 -828 -910 15446 -910 -828 -703 -552 -707 ;
]',
    'CSET coefficient_reload = fixed_coefficients',
    'CSET coefficient_width = 18',
    'CSET filter_type = single_rate_fir',
    'CSET impulse_response = symmetric',
    'CSET input_data_type = unsigned',
    'CSET input_data_width = 32',
    'CSET number_of_channels = 1',
    'CSET number_of_taps = 11',
    'CSET optimize_coefficients = true',
    'CSET register_output = false',
    'CSET reset = true',
    'CSET sample_rate_change = 1',
    'CSET zero_packing_factor = 1',
    'SET devicefamily = Virtex4',
    'SET xilinxfamily = Virtex4',
    'CSET component_name = distributed_arithmetic_fir_filter_virtex4_9_0_d7a6888f1f6006cd',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '5efd99aa998bea1facb0ea26ce9a9e56',
    'sourceFile' => 'hdl/xlfir_1ch.vhd',
    'templateKeyValues' => {
      'core_name' => 'distributed_arithmetic_fir_filter_virtex4_9_0_d7a6888f1f6006cd',
      'core_name0' => 'distributed_arithmetic_fir_filter_virtex4_9_0_d7a6888f1f6006cd',
      'entity_name' => 'xlfir_1ch_distributed_arithmetic_fir_filter_virtex4_9_0_d7a6888f1f6006cdf90e',
      'generic_map' => 'sel_width : integer := 1;
    din0_width : integer := 32;
    din0_bin_pt : integer := 0;
    din0_arith : integer := xlUnsigned;
    dout0_width : integer := 49;
    dout0_bin_pt : integer := 14;
    dout0_arith : integer := xlSigned;
    c_result_width : integer := 49;
    c_polyphase_factor : integer := 1;
    latency : integer := 20;
    interpolating : integer := 0;
    extra_registers : integer := 8',
      'needs_core' => 1,
      'port_instance' => '    din0 => din0,
    dout0 => dout0,',
      'port_map' => '    din0: in std_logic_vector(din0_width - 1 downto 0) := (others => \'0\');
    dout0: out std_logic_vector(dout0_width - 1 downto 0) := (others => \'0\');',
      'sel_width' => '1',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '131f1f4620e5e2dcfff00eef4137c57c',
    'sourceFile' => 'C:/xilinx/10.1/DSP_Tools/sysgen/hdl/xldelay.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '2167e70c3e2052b5221553e28e27d105',
    'sourceFile' => 'C:/xilinx/10.1/DSP_Tools/sysgen/hdl/xldelay.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '1a63fbb8673b474157b380e698f46b9d',
    'sourceFile' => 'C:/xilinx/10.1/DSP_Tools/sysgen/hdl/xldelay.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'c754fbbbfbd81d92306d366b3c493d72',
    'sourceFile' => 'C:/xilinx/10.1/DSP_Tools/sysgen/hdl/xldelay.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '2d448536cf95b4e9d3a2144e2a791adf',
    'sourceFile' => 'C:/xilinx/10.1/DSP_Tools/sysgen/hdl/xldelay.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '119a7952870b36f4a31e5bfcbd39d123',
    'sourceFile' => 'C:/xilinx/10.1/DSP_Tools/sysgen/hdl/xldelay.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'ccada3a8838cfe3725bc19e38dba7f67',
    'sourceFile' => 'C:/xilinx/10.1/DSP_Tools/sysgen/hdl/xldelay.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '4e3dc467c35bad45f82fbdbcdee9ba05',
    'sourceFile' => 'C:/xilinx/10.1/DSP_Tools/sysgen/hdl/xldelay.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'a03d2937ab65e4cc676ba872e447cbd1',
    'sourceFile' => 'C:/xilinx/10.1/DSP_Tools/sysgen/hdl/xldelay.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator Virtex5 Xilinx,_Inc. 2.4',
    '# 10.1.03i',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = true',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Use_ENB_Pin',
    'CSET load_init_file = TRUE',
    'CSET memory_type = True_Dual_Port_RAM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 36',
    'CSET read_width_b = 36',
    'CSET register_output_of_memory_core = false',
    'CSET register_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET use_byte_write_enable = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_ssra_pin = FALSE',
    'CSET use_ssrb_pin = FALSE',
    'CSET write_depth_a = 1024',
    'CSET write_width_a = 36',
    'CSET write_width_b = 36',
    'CSET component_name = bmg_24_vx5_50a13050f3c3c10e',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'e86a8f33a5605e7e5366254a91c9d89a',
    'sourceFile' => 'hdl/xldpram.vhd',
    'templateKeyValues' => {
      'core_component_def' => 'addra: in std_logic_vector(c_address_width_a - 1 downto 0);
      addrb: in std_logic_vector(c_address_width_b - 1 downto 0);
      dina: in std_logic_vector(c_width_a - 1 downto 0);
      dinb: in std_logic_vector(c_width_b - 1 downto 0);
      clka: in std_logic;
      clkb: in std_logic;
      wea: in std_logic_vector(0 downto 0);
      web: in std_logic_vector(0 downto 0);
      ena: in std_logic;
      enb: in std_logic;
      douta: out std_logic_vector(c_width_a - 1 downto 0);
      doutb: out std_logic_vector(c_width_b - 1 downto 0)',
      'core_instance_text' => 'addra => core_addra,
        clka => a_clk,
        addrb => core_addrb,
        clkb => b_clk,
        dina => core_dina,
        wea(0) => core_wea,
        dinb => core_dinb,
        web(0) => core_web,
        ena => core_a_ce,
        enb => core_b_ce,
        douta => core_douta,
        doutb => core_doutb',
      'core_name0' => 'bmg_24_vx5_50a13050f3c3c10e',
      'entity_name.0' => 'xldpram',
      'needs_core' => 1,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Block_Memory_Generator Virtex5 Xilinx,_Inc. 2.4',
    '# 10.1.03i',
    'CSET algorithm = Minimum_Area',
    'CSET assume_synchronous_clk = true',
    'CSET byte_size = 9',
    'CSET coe_file = [
',
    '  MEMORY_INITIALIZATION_RADIX = 16;',
    '  MEMORY_INITIALIZATION_VECTOR = 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0;',
    '
]',
    'CSET collision_warnings = ALL',
    'CSET disable_collision_warnings = false',
    'CSET enable_a = Use_ENA_Pin',
    'CSET enable_b = Use_ENB_Pin',
    'CSET load_init_file = TRUE',
    'CSET memory_type = True_Dual_Port_RAM',
    'CSET operating_mode_a = WRITE_FIRST',
    'CSET operating_mode_b = WRITE_FIRST',
    'CSET output_reset_value_a = 0',
    'CSET output_reset_value_b = 0',
    'CSET primitive = 8kx2',
    'CSET read_width_a = 32',
    'CSET read_width_b = 32',
    'CSET register_output_of_memory_core = false',
    'CSET register_output_of_memory_primitives = false',
    'CSET remaining_memory_locations = 0',
    'CSET use_byte_write_enable = false',
    'CSET use_regcea_pin = false',
    'CSET use_regceb_pin = false',
    'CSET use_ssra_pin = FALSE',
    'CSET use_ssrb_pin = FALSE',
    'CSET write_depth_a = 1024',
    'CSET write_width_a = 32',
    'CSET write_width_b = 32',
    'CSET component_name = bmg_24_vx5_f169ae5f8f6da006',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '92a541644479dd045199702f1921b17a',
    'sourceFile' => 'hdl/xldpram.vhd',
    'templateKeyValues' => {
      'core_component_def' => 'addra: in std_logic_vector(c_address_width_a - 1 downto 0);
      addrb: in std_logic_vector(c_address_width_b - 1 downto 0);
      dina: in std_logic_vector(c_width_a - 1 downto 0);
      dinb: in std_logic_vector(c_width_b - 1 downto 0);
      clka: in std_logic;
      clkb: in std_logic;
      wea: in std_logic_vector(0 downto 0);
      web: in std_logic_vector(0 downto 0);
      ena: in std_logic;
      enb: in std_logic;
      douta: out std_logic_vector(c_width_a - 1 downto 0);
      doutb: out std_logic_vector(c_width_b - 1 downto 0)',
      'core_instance_text' => 'addra => core_addra,
        clka => a_clk,
        addrb => core_addrb,
        clkb => b_clk,
        dina => core_dina,
        wea(0) => core_wea,
        dinb => core_dinb,
        web(0) => core_web,
        ena => core_a_ce,
        enb => core_b_ce,
        douta => core_douta,
        doutb => core_doutb',
      'core_name0' => 'bmg_24_vx5_f169ae5f8f6da006',
      'entity_name.0' => 'xldpram',
      'needs_core' => 1,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Fast_Fourier_Transform Virtex5 Xilinx,_Inc. 6.0',
    '# 10.1.03i',
    'CSET ce = true',
    'CSET channels = 1',
    'CSET cyclic_prefix_insertion = false',
    'CSET data_format = fixed_point',
    'CSET fast_butterfly = false',
    'CSET fast_complex_mult = false',
    'CSET implementation_options = pipelined_streaming_io',
    'CSET input_width = 14',
    'CSET memory_options_data = block_ram',
    'CSET memory_options_hybrid = false',
    'CSET memory_options_phase_factors = block_ram',
    'CSET memory_options_reorder = block_ram',
    'CSET number_of_stages_using_block_ram_for_data_and_phase_factors = 1',
    'CSET optimize_for_speed_using_xtreme_dsp_slices = false',
    'CSET output_ordering = natural_order',
    'CSET ovflo = false',
    'CSET phase_factor_width = 32',
    'CSET rounding_modes = convergent_rounding',
    'CSET run_time_configurable_transform_length = false',
    'CSET scaling_options = block_floating_point',
    'CSET sclr = false',
    'CSET target_clock_frequency = 250',
    'CSET target_data_throughput = 50',
    'CSET transform_length = 1024',
    'CSET component_name = fast_fourier_transform_virtex5_6_0_10e7546511e1d7fa',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '52487f1f09b593ef10d918aca9a4830d',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => ' is
  component fast_fourier_transform_virtex5_6_0_10e7546511e1d7fa
    port(
      blk_exp:out std_logic_vector(4 downto 0);
      busy:out std_logic;
      ce:in std_logic;
      clk:in std_logic;
      done:out std_logic;
      dv:out std_logic;
      edone:out std_logic;
      fwd_inv:in std_logic;
      fwd_inv_we:in std_logic;
      rfd:out std_logic;
      start:in std_logic;
      xk_im:out std_logic_vector(13 downto 0);
      xk_index:out std_logic_vector(9 downto 0);
      xk_re:out std_logic_vector(13 downto 0);
      xn_im:in std_logic_vector(13 downto 0);
      xn_index:out std_logic_vector(9 downto 0);
      xn_re:in std_logic_vector(13 downto 0)
    );
end component;
begin
  fast_fourier_transform_virtex5_6_0_10e7546511e1d7fa_instance : fast_fourier_transform_virtex5_6_0_10e7546511e1d7fa
    port map(
      blk_exp=>blk_exp,
      busy=>busy,
      ce=>ce,
      clk=>clk,
      done=>done,
      dv=>dv,
      edone=>edone,
      fwd_inv=>fwd_inv,
      fwd_inv_we=>fwd_inv_we,
      rfd=>rfd,
      start=>start,
      xk_im=>xk_im,
      xk_index=>xk_index,
      xk_re=>xk_re,
      xn_im=>xn_im,
      xn_index=>xn_index,
      xn_re=>xn_re
    );
end ',
      'crippled_entity' => 'is 
  port(
    blk_exp:out std_logic_vector(4 downto 0);
    busy:out std_logic;
    ce:in std_logic;
    clk:in std_logic;
    done:out std_logic;
    dv:out std_logic;
    edone:out std_logic;
    fwd_inv:in std_logic;
    fwd_inv_we:in std_logic;
    rfd:out std_logic;
    start:in std_logic;
    xk_im:out std_logic_vector(13 downto 0);
    xk_index:out std_logic_vector(9 downto 0);
    xk_re:out std_logic_vector(13 downto 0);
    xn_im:in std_logic_vector(13 downto 0);
    xn_index:out std_logic_vector(9 downto 0);
    xn_re:in std_logic_vector(13 downto 0)
  );
end',
      'entity_name' => 'xlFast_Fourier_Transform_59dca8661281bf2ead46d5bd7e50772d',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = [
    'SELECT Multiplier Virtex5 Xilinx,_Inc. 10.1',
    '# 10.1.03i',
    'CSET ccmimp = Distributed_Memory',
    'CSET clockenable = true',
    'CSET constvalue = 129',
    'CSET internaluser = 0',
    'CSET multiplier_construction = Use_LUTs',
    'CSET multtype = Parallel_Multiplier',
    'CSET outputwidthhigh = 27',
    'CSET outputwidthlow = 0',
    'CSET pipestages = 3',
    'CSET portatype = Signed',
    'CSET portawidth = 14',
    'CSET portbtype = Signed',
    'CSET portbwidth = 14',
    'CSET roundpoint = 0',
    'CSET sclrcepriority = CE_Overrides_SCLR',
    'CSET syncclear = true',
    'CSET use_custom_output_width = false',
    'CSET userounding = false',
    'CSET zerodetect = false',
    'CSET component_name = multiplier_virtex5_10_1_bcea1407c76f9e63',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'fce492e76d46e44910b7b941d64c5fc6',
    'sourceFile' => 'hdl/xlmult_v9_0.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      b: in std_logic_vector(c_b_width - 1 downto 0);
      p: out std_logic_vector(c_output_width - 1 downto 0);
      clk: in std_logic;
      ce: in std_logic;
      sclr: in std_logic;
      a: in std_logic_vector(c_a_width - 1 downto 0)',
      'core_instance_text' => '        a => tmp_a,
        clk => clk,
        ce => internal_ce,
        sclr => internal_clr,
        p => tmp_p,
        b => tmp_b',
      'core_name0' => 'multiplier_virtex5_10_1_bcea1407c76f9e63',
      'entity_name.0' => 'xlmult_v9_0',
      'needs_core' => 1,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'e8116729378e385527cd63f9ca4fba73',
    'sourceFile' => 'C:/xilinx/10.1/DSP_Tools/sysgen/hdl/xlregister.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '292095c11a7db1a51eaa128aa457c7d6',
    'sourceFile' => 'C:/xilinx/10.1/DSP_Tools/sysgen/hdl/xlregister.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'ad6620331827f723fe31236294cc17ed',
    'sourceFile' => 'C:/xilinx/10.1/DSP_Tools/sysgen/hdl/xlregister.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'e68f4ba478010e3b7e7501afbd7e3ead',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
  signal input_port_1_40: signed((29 - 1) downto 0);
  signal output_port_5_5_force: unsigned((29 - 1) downto 0);
begin
  input_port_1_40 <= std_logic_vector_to_signed(input_port);
  output_port_5_5_force <= signed_to_unsigned(input_port_1_40);
  output_port <= unsigned_to_std_logic_vector(output_port_5_5_force);
end',
      'crippled_entity' => 'is
  port (
    input_port : in std_logic_vector((29 - 1) downto 0);
    output_port : out std_logic_vector((29 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'reinterpret_6243b013c6',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '55ea1daec99964e162d26d3595ca3d2d',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
  signal a_1_31: unsigned((10 - 1) downto 0);
  signal b_1_34: unsigned((10 - 1) downto 0);
  type array_type_op_mem_32_22 is array (0 to (1 - 1)) of boolean;
  signal op_mem_32_22: array_type_op_mem_32_22 := (
    0 => false);
  signal op_mem_32_22_front_din: boolean;
  signal op_mem_32_22_back: boolean;
  signal op_mem_32_22_push_front_pop_back_en: std_logic;
  signal result_12_3_rel: boolean;
begin
  a_1_31 <= std_logic_vector_to_unsigned(a);
  b_1_34 <= std_logic_vector_to_unsigned(b);
  op_mem_32_22_back <= op_mem_32_22(0);
  proc_op_mem_32_22: process (clk)
  is
    variable i: integer;
  begin
    if (clk\'event and (clk = \'1\')) then
      if ((ce = \'1\') and (op_mem_32_22_push_front_pop_back_en = \'1\')) then
        op_mem_32_22(0) <= op_mem_32_22_front_din;
      end if;
    end if;
  end process proc_op_mem_32_22;
  result_12_3_rel <= a_1_31 = b_1_34;
  op_mem_32_22_front_din <= result_12_3_rel;
  op_mem_32_22_push_front_pop_back_en <= \'1\';
  op <= boolean_to_vector(op_mem_32_22_back);
end',
      'crippled_entity' => 'is
  port (
    a : in std_logic_vector((10 - 1) downto 0);
    b : in std_logic_vector((10 - 1) downto 0);
    op : out std_logic_vector((1 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'relational_741ee37bac',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '09521f1c6fc8b81eda206ffa6fe0c1ca',
    'sourceFile' => 'C:/xilinx/10.1/DSP_Tools/sysgen/hdl/xlslice.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Distributed_Arithmetic_FIR_Filter Virtex4 Xilinx,_Inc. 9.0',
    '# 10.1.03i',
    'CSET clock_cycles_per_sample = 1',
    'CSET coefficient_data_type = signed',
    'CSET coefficient_file = [
 Radix=10;
Coefdata = -707 -552 -703 -828 -910 15446 -910 -828 -703 -552 -707 ;
]',
    'CSET coefficient_reload = fixed_coefficients',
    'CSET coefficient_width = 18',
    'CSET filter_type = single_rate_fir',
    'CSET impulse_response = symmetric',
    'CSET input_data_type = unsigned',
    'CSET input_data_width = 32',
    'CSET number_of_channels = 1',
    'CSET number_of_taps = 11',
    'CSET optimize_coefficients = true',
    'CSET register_output = false',
    'CSET reset = true',
    'CSET sample_rate_change = 1',
    'CSET zero_packing_factor = 1',
    'SET devicefamily = Virtex4',
    'SET xilinxfamily = Virtex4',
    'CSET component_name = distributed_arithmetic_fir_filter_virtex4_9_0_d7a6888f1f6006cd',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '8c75b9c9e163869cac097c928ebbfd2c',
    'sourceFile' => 'hdl/xlfir_1ch.vhd',
    'templateKeyValues' => {
      'core_name' => 'distributed_arithmetic_fir_filter_virtex4_9_0_d7a6888f1f6006cd',
      'core_name0' => 'distributed_arithmetic_fir_filter_virtex4_9_0_d7a6888f1f6006cd',
      'entity_name' => 'xlfir_1ch_distributed_arithmetic_fir_filter_virtex4_9_0_d7a6888f1f6006cd79c7',
      'generic_map' => 'sel_width : integer := 1;
    din0_width : integer := 32;
    din0_bin_pt : integer := 0;
    din0_arith : integer := xlUnsigned;
    dout0_width : integer := 49;
    dout0_bin_pt : integer := 14;
    dout0_arith : integer := xlSigned;
    c_result_width : integer := 49;
    c_polyphase_factor : integer := 1;
    latency : integer := 20;
    interpolating : integer := 0;
    extra_registers : integer := 8',
      'needs_core' => 1,
      'port_instance' => '    din0 => din0,
    dout0 => dout0,',
      'port_map' => '    din0: in std_logic_vector(din0_width - 1 downto 0) := (others => \'0\');
    dout0: out std_logic_vector(dout0_width - 1 downto 0) := (others => \'0\');',
      'sel_width' => '1',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = [
    'SELECT Distributed_Arithmetic_FIR_Filter Virtex4 Xilinx,_Inc. 9.0',
    '# 10.1.03i',
    'CSET clock_cycles_per_sample = 1',
    'CSET coefficient_data_type = signed',
    'CSET coefficient_file = [
 Radix=10;
Coefdata = -707 -552 -703 -828 -910 15446 -910 -828 -703 -552 -707 ;
]',
    'CSET coefficient_reload = fixed_coefficients',
    'CSET coefficient_width = 18',
    'CSET filter_type = single_rate_fir',
    'CSET impulse_response = symmetric',
    'CSET input_data_type = unsigned',
    'CSET input_data_width = 32',
    'CSET number_of_channels = 1',
    'CSET number_of_taps = 11',
    'CSET optimize_coefficients = true',
    'CSET register_output = false',
    'CSET reset = true',
    'CSET sample_rate_change = 1',
    'CSET zero_packing_factor = 1',
    'SET devicefamily = Virtex4',
    'SET xilinxfamily = Virtex4',
    'CSET component_name = distributed_arithmetic_fir_filter_virtex4_9_0_d7a6888f1f6006cd',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'ded8c9b373c564fa0dd844798c4f8fc6',
    'sourceFile' => 'hdl/xlfir_1ch.vhd',
    'templateKeyValues' => {
      'core_name' => 'distributed_arithmetic_fir_filter_virtex4_9_0_d7a6888f1f6006cd',
      'core_name0' => 'distributed_arithmetic_fir_filter_virtex4_9_0_d7a6888f1f6006cd',
      'entity_name' => 'xlfir_1ch_distributed_arithmetic_fir_filter_virtex4_9_0_d7a6888f1f6006cd3813',
      'generic_map' => 'sel_width : integer := 1;
    din0_width : integer := 32;
    din0_bin_pt : integer := 0;
    din0_arith : integer := xlUnsigned;
    dout0_width : integer := 49;
    dout0_bin_pt : integer := 14;
    dout0_arith : integer := xlSigned;
    c_result_width : integer := 49;
    c_polyphase_factor : integer := 1;
    latency : integer := 20;
    interpolating : integer := 0;
    extra_registers : integer := 8',
      'needs_core' => 1,
      'port_instance' => '    din0 => din0,
    dout0 => dout0,',
      'port_map' => '    din0: in std_logic_vector(din0_width - 1 downto 0) := (others => \'0\');
    dout0: out std_logic_vector(dout0_width - 1 downto 0) := (others => \'0\');',
      'sel_width' => '1',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'b32a0080f8f47e0be7ec44c6ad81b20b',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
  signal ip_1_26: boolean;
  type array_type_op_mem_22_20 is array (0 to (1 - 1)) of boolean;
  signal op_mem_22_20: array_type_op_mem_22_20 := (
    0 => false);
  signal op_mem_22_20_front_din: boolean;
  signal op_mem_22_20_back: boolean;
  signal op_mem_22_20_push_front_pop_back_en: std_logic;
  signal internal_ip_12_1_bitnot: boolean;
begin
  ip_1_26 <= ((ip) = "1");
  op_mem_22_20_back <= op_mem_22_20(0);
  proc_op_mem_22_20: process (clk)
  is
    variable i: integer;
  begin
    if (clk\'event and (clk = \'1\')) then
      if ((ce = \'1\') and (op_mem_22_20_push_front_pop_back_en = \'1\')) then
        op_mem_22_20(0) <= op_mem_22_20_front_din;
      end if;
    end if;
  end process proc_op_mem_22_20;
  internal_ip_12_1_bitnot <= ((not boolean_to_vector(ip_1_26)) = "1");
  op_mem_22_20_push_front_pop_back_en <= \'0\';
  op <= boolean_to_vector(internal_ip_12_1_bitnot);
end',
      'crippled_entity' => 'is
  port (
    ip : in std_logic_vector((1 - 1) downto 0);
    op : out std_logic_vector((1 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'inverter_e5b38cca3b',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '298203483c3de52896eed04fd75246a4',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
  signal d0_1_24: std_logic;
  signal d1_1_27: std_logic;
  signal fully_2_1_bit: std_logic;
begin
  d0_1_24 <= d0(0);
  d1_1_27 <= d1(0);
  fully_2_1_bit <= d0_1_24 and d1_1_27;
  y <= std_logic_to_vector(fully_2_1_bit);
end',
      'crippled_entity' => 'is
  port (
    d0 : in std_logic_vector((1 - 1) downto 0);
    d1 : in std_logic_vector((1 - 1) downto 0);
    y : out std_logic_vector((1 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'logical_80f90b97d0',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '3a4345c7abdbe98b891d80de2cb8b324',
    'sourceFile' => 'C:/xilinx/10.1/DSP_Tools/sysgen/hdl/xlregister.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '3c4a46d8180ea33a7903fbb735718835',
    'sourceFile' => 'C:/my_work/three_beam_wfil/black_box_nofil.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  local *wrapup = $Sg::{'wrapup'};
  push(@$results, &Sg::wrapup())   if (defined(&wrapup));
  local *wrapup = $SgDeliverFile::{'wrapup'};
  push(@$results, &SgDeliverFile::wrapup())   if (defined(&wrapup));
  local *wrapup = $SgGenerateCores::{'wrapup'};
  push(@$results, &SgGenerateCores::wrapup())   if (defined(&wrapup));
  use Carp qw(croak);
  $ENV{'SYSGEN'} = 'C:/xilinx/10.1/DSP_Tools/sysgen';
  open(RESULTS, '> C:/my_work/three_beam_wfil/sysgen/script_results19870') || 
    croak 'couldn\'t open C:/my_work/three_beam_wfil/sysgen/script_results19870';
  binmode(RESULTS);
  print RESULTS &Sg::toString($results) . "\n";
  close(RESULTS) || 
    croak 'trouble writing C:/my_work/three_beam_wfil/sysgen/script_results19870';
};

if ($@) {
  open(RESULTS, '> C:/my_work/three_beam_wfil/sysgen/script_results19870') || 
    croak 'couldn\'t open C:/my_work/three_beam_wfil/sysgen/script_results19870';
  binmode(RESULTS);
  print RESULTS $@ . "\n";
  close(RESULTS) || 
    croak 'trouble writing C:/my_work/three_beam_wfil/sysgen/script_results19870';
  exit(1);
}

exit(0);
